﻿<?php
$action1 = $_POST["txtloginname"];
echo"<script>alert('$action1')</script>";
$action1 = $_POST["txtPassword"];
echo"<script>alert('$action1')</script>";
$action1 = $_POST["yd631_sex"];
echo"<script>alert('$action1')</script>";
$action1 = $_POST["yd631_age"];
echo"<script>alert('$action1')</script>";
$action1 = $_POST["yd631_call"];
echo"<script>alert('$action1')</script>";

$action1 = $_POST["txtemail"];
echo"<script>alert('$action1')</script>";

$action1 = $_POST["code"];
echo"<script>alert('$action1')</script>";

$action1 = $_POST["txtZip"];
echo"<script>alert('$action1')</script>";

$action1 = $_POST["txtMobilephone"];
echo"<script>alert('$action1')</script>";

$action1 = $_POST["txtPhone"];
echo"<script>alert('$action1')</script>";

$action1 = $_POST["txtOtherphone"];
echo"<script>alert('$action1')</script>";


$action1 = $_POST["txtQQ"];
echo"<script>alert('$action1')</script>";

$action1 = $_POST["yd631_address"];
echo"<script>alert('$action1')</script>";


?>
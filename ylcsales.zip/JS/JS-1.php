﻿<html>
<head>
	<title>jQuery简单示例</title>
	<script src="../js/jquery-1.11.3.js" type="text/javascript"></script>
	<script type="text/javascript">
		$(document).ready(function(){
	alert('Hello ShopNC');             
		});
	</script>
</head>
<body>
</body>
</html>

﻿<html>
<head>
<script type="text/javascript" src="../js/jquery-1.11.3.js"></script>
<script type="text/javascript">
$(document).ready(function(){
  $("#testDiv1").bind("click",function(){
	  alert("!!!");
  });
});

</script>
</head>
<body>
<div id="testDiv1">单击事件1</div>
</body>
</html>

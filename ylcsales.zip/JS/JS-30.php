﻿<!DOCTYPE html>
<html>
<head>
<script src="../js/jquery-1.11.3.js"></script>
<script type="text/javascript">
$(document).ready(function(){
  $("button").click(function(){
  $("p").toggle();
  });
});
</script>
</head>
<body>
<button type="button">切换</button>
<p>ShopNC</p>

</body>
</html>
﻿<html>
<head>
<script type="text/javascript" src="../js/jquery-1.11.3.js"></script>
<script type="text/javascript">
	function check_alert(){
	var content = $("li").html();
	alert(content);

	}
</script>
</head>
<body>
<p><a href="http://www.shopnc.net">ShopNC</a></p>
<li><a href="http://www.shopnc.net">ShopNC</a></li>
<input type="button" value="输出结果" onclick="check_alert()" />
</body>
</html>


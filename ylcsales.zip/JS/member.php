﻿<?php
echo "1";
$username1=$_POST["username"];
//echo"<script>alert('$username1')</script>";
?>
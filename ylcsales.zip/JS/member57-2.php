﻿<?php
$action1 = $_POST["username"];
$action2 = $_POST["dh"];
$action3 = $_POST["action"];
$action4 = $_POST["password"];
echo"<script>alert('$action1')</script>";
echo"<script>alert('$action2')</script>";
echo"<script>alert('$action3')</script>";
echo"<script>alert('$action4')</script>";

?>
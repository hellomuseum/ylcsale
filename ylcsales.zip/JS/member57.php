﻿<?php
//$action1 = $_POST["username"];
//$username = 1;
echo 1;

?>
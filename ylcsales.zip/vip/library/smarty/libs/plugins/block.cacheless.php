<?php 
function smarty_block_cacheless($param, $content, &$smarty) { 
return $content;        
}
?>

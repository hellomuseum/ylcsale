<?php
/**
 * 模板引擎类
 *
 */
class TemplatesClass {
	/**
	 * 模板对象
	 *
	 * @var obj
	 */
	private $tpl;
	/**
	 * 构造函数
	 *
	 */
	public function __construct(){
		require_once(BasePath."/library/smarty/libs/Smarty.class.php");
		$this->tpl = new Smarty();
		//关闭调试模式
		$this->tpl->debugging = false;
		//模板文件的存放目录
		$this->tpl->template_dir = BasePath.'/templates/';
		//模板编译文件的存放目录
		$this->tpl->compile_dir = BasePath.'/templates/templates_c/';
		//自定义模板标记
		$this->tpl->left_delimiter = '<{';
		$this->tpl->right_delimiter = '}>';
	}
	/**
	 * 向模板抛出变量
	 *
	 * @param string $key
	 * @param string $value
	 */
	public function assign($key,$value){
		$this->tpl->assign($key,$value);
	}
	/**
	 * 调用模板页并显示
	 *
	 * @param string $page
	 */
	public function display($page){
		$this->tpl->display($page);
	}

}
?>